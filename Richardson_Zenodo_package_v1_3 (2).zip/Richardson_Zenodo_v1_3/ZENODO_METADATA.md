# Поля записи Zenodo

Четвёртая редакция, версия пакета: 1.3. Дата подготовки: 20 сентября 2026 года. Сам пакет не означает, что запись уже опубликована.

| Поле | Готовое значение или действие |
| --- | --- |
| Resource type | Publication → Working paper |
| Title | Selberg Integrals and Particle–Hole Duality in the Richardson–Gaudin Pairing Model |
| Creator: family name | Pogosov |
| Creator: given names | Walter V. |
| Version | 1.3 |
| Language | English |
| Description | Текст из `ZENODO_DESCRIPTION.txt`; для редактора, принимающего HTML, — `ZENODO_DESCRIPTION.html` |
| Publication date | Дата фактического опубликования записи |
| DOI | DOI этой версии; при уже опубликованной записи используйте New version, иначе создайте первую запись |
| License | Выбрать автору в форме Zenodo; пакет не назначает лицензию от его имени |
| Visibility | Public — для предполагаемого открытого размещения |

**Подзаголовок рукописи:** Exact Periods, Self-Dual States, and Finite-Size Crossover. Он воспроизведён в Description; это не дополнительное обязательное поле формы Zenodo.

ORCID и текущая аффилиация не внесены: при желании укажите свои актуальные данные в форме. LLM не добавляется в список авторов; её вклад описан в первом абзаце Description и в начале рукописи.

Ключевые слова, по одному на поле:

```text
Richardson–Gaudin model
reduced BCS Hamiltonian
Selberg integrals
residue calculus
determinant identities
Pfaffians
quaternionic Grassmann integrals
Jack polynomials
matrix hypergeometric functions
orthogonal polynomials
one-pair saddle expansion
electron–hole symmetry
particle–hole duality
self-dual states
BCS crossover
condensation energy
excitation gaps
nonlocal boundary equations
pairing correlations
finite-size effects
LLM-assisted research
iterative collaborative research
```

## Related identifiers

Для следующих DOI выберите отношение **References**. Они относятся к предшествующим работам, а не к новой записи.

| Identifier | Identifier type | Relation | Работа |
| --- | --- | --- | --- |
| 10.1088/0953-8984/24/7/075701 | DOI | References | J. Phys.: Condens. Matter 24, 075701 (2012) |
| 10.1143/PTP.128.1 | DOI | References | Prog. Theor. Phys. 128, 1–14 (2012) |
| 10.13140/2.1.1066.5766 | DOI | References | Докторская диссертация, 2014; копия ResearchGate |
| 10.1016/j.nuclphysb.2015.05.031 | DOI | References | Bork–Pogosov, Nuclear Physics B 897, 405–420 (2015) |
| 10.1103/PhysRevB.83.235124 | DOI | References | Faribault et al., Physical Review B 83, 235124 (2011) |
| 10.1088/1751-8113/45/48/485202 | DOI | References | Faribault–Schuricht, Journal of Physics A 45, 485202 (2012) |
| 10.1016/j.nuclphysb.2017.01.005 | DOI | References | Links, Nuclear Physics B 916 (2017) |
| 10.1016/j.ssc.2014.12.025 | DOI | References | Pogosov, Solid State Communications 207, 1–4 (2015); arXiv:1412.1015 |
| 10.1103/PhysRevB.63.214518 | DOI | References | Schechter–Imry–Levinson–von Delft, Physical Review B 63, 214518 (2001) |
| 10.1103/PhysRevB.71.094505 | DOI | References | Yuzbashyan–Baytin–Altshuler, Physical Review B 71, 094505 (2005) |

Ссылки arXiv и обе ссылки на диссертацию уже включены в Description, README и библиографию рукописи. Отдельное поле Funding можно оставить пустым, если для этой версии не нужно указать конкретное финансирование.

## Содержимое для загрузки

Загрузите все файлы из папки `UPLOAD/` как одну запись. Основной PDF `RG_Selberg_Duality_working_manuscript_v1_3.pdf` доступен отдельно для просмотра; `RG_Selberg_Duality_sources_and_checks_v1_3.zip` содержит источники и вычислительные материалы. Остальные файлы поясняют состав записи, цитирование и контрольные суммы.

Эта таблица предназначена для ручного заполнения формы. Загрузка её как файла сама по себе не заполняет метаданные Zenodo.

Сведения о форме проверены по официальным инструкциям: [создание записи](https://help.zenodo.org/docs/deposit/create-new-upload/), [выбор типа ресурса](https://help.zenodo.org/docs/deposit/describe-records/resource-type/), [лицензии](https://help.zenodo.org/docs/deposit/describe-records/licenses/).

Обновление 1.3 добавляет главы 23–25 о самодуальной полиномиальной линии, основном состоянии, щелях и критериях БКШ, а также о скалярном условии и вещественном отклике возбуждённой ветви. Название изменено, прежние главы сохранены. Всего 25 глав и 14 приложений. Точные конечные тождества, контролируемые пределы, численные наблюдения и открытые задачи разделены явно. Если предыдущая запись опубликована, используйте [создание новой версии](https://help.zenodo.org/docs/deposit/manage-versions/).
