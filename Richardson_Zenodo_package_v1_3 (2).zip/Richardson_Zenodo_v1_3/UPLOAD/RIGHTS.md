# Licence selection for the deposit

This preparation package does not assign a reuse licence on the author's behalf. This file is a note about that pending metadata choice; it is not a licence text.

When creating the Zenodo record, the depositor should select the intended licence for the manuscript and accompanying material, and ensure that the record and any licence files agree. The absence of a licence identifier in the draft citation files is intentional.

Earlier publications and the dissertation are cited by their bibliographic records and links. Copies of those third-party-hosted documents are not redistributed in this package.
