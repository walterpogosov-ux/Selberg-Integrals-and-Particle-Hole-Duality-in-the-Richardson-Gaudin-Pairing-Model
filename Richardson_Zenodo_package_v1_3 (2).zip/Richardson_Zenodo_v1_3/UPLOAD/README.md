# Selberg Integrals and Particle–Hole Duality in the Richardson–Gaudin Pairing Model

**W. V. Pogosov — LLM-assisted working manuscript, version 1.3 (fourth prepared edition)**  
Prepared 20 September 2026 for deposition on Zenodo.

## Authorship, provenance, and verification

The scientific problem, original method, and research direction belong to W. V. Pogosov. This project builds on his published and unpublished work developed before the involvement of an advanced large language model (LLM). During the subsequent LLM-assisted phase, the LLM produced detailed derivations, calculations, and verification programs through an extended collaboration with the author. The author has not exhaustively verified every calculation and proof.

The research developed through many iterations and branching lines of enquiry over a substantial period of time. The author posed and refined questions, assessed proposed directions, and guided the revision, rejection, and combination of intermediate approaches; the LLM supplied calculations and arguments that prompted further questions and revisions. The resulting manuscript is a record of this reciprocal, sustained research process.

## Origin and purpose

The method was proposed for the ground state in W. V. Pogosov, “`Probabilistic' approach to Richardson equations,” *J. Phys.: Condens. Matter* **24**, 075701 (2012): [journal DOI](https://doi.org/10.1088/0953-8984/24/7/075701), [arXiv:1111.2907](https://arxiv.org/abs/1111.2907). That paper extracted the interaction dependence needed for the energy, leaving a coupling-independent normalization undetermined. In this line of work it also first formulated explicitly the Hamiltonian origin of electron–hole symmetry in the exact Richardson analysis; its Appendix A acknowledges earlier observations of spectral duality.

The extension to excited states appeared in “Excited states in Richardson pairing model: `probabilistic' approach,” *Prog. Theor. Phys.* **128**, 1–14 (2012): [journal DOI](https://doi.org/10.1143/PTP.128.1), [arXiv:1208.1088](https://arxiv.org/abs/1208.1088). The common determinant normalization was again not evaluated directly.

The author's 2014 Doctor of Physical and Mathematical Sciences dissertation, **«Сверхпроводники и разреженные сверхтекучие бозе-системы: от микро- к макроуровню»**, developed direct determinant evaluations using successive row differences and triangular reduction. It was prepared at the Institute for Theoretical and Applied Electrodynamics, Russian Academy of Sciences. See the [Lebedev dissertation-council record](https://www.lebedev.ru/ru/fian-dissertation-councils/posts.html?id=188) and the [complete thesis on ResearchGate](https://www.researchgate.net/publication/271840408_Sverhprovodniki_i_razrezennye_sverhtekucie_boze-sistemy_ot_mikro-_k_makrourovnu), [DOI](https://doi.org/10.13140/2.1.1066.5766).

After the papers and dissertation, the author obtained further results and working materials that remained unpublished. Only after this accumulated body of work existed was an advanced LLM introduced to the project.

From the perspective of the broader program pursued here, those results were a partial solution. This project attempts to complete and control the determinant and contour approach, including excitation sectors and finite-size asymptotics. It does not claim that this objective has already been achieved.

## Contents and scientific status

The full English text has twenty-five chapters and fourteen appendices. It develops exact finite period algebra and asymptotics of specified meromorphic integrals. It distinguishes those statements from their interpretation as physical Richardson eigenenergies.

The lattice revision retained from version 1.0 repairs the off-lattice source interpolation used in the confluent-minor argument: saddle localization and an exponentially small error on the integer lattice recover the stated fixed-size minor law within the specified compact interior regime.

The following remain open inputs in the broader manuscript: contour and physical branch selection outside the established Case A finite-system large-p bridge, uniform Gaussian energy control in growing dimension, the proposed Hessian-to-spectral-shift identification, and some blocked-period prefactor and physical finite-defect comparisons. The identification of the period endpoint with the physical real-root density is also conjectural. The manuscript's opening scope page and final open-problem chapter give the details.

Version 1.1 added Chapter 20 on the **Case A common all-pole period** at doubled auxiliary inverse temperature: explicit fourth-power moment Pfaffians, a positive quaternionic Grassmann representation and nonvanishing theorem, and fixed-spectrum weak/strong coupling comparisons. New mixed-contour or cascade Pfaffian results for Case B are not included.

Version 1.2 adds Chapter 21 on the **Case A common all-pole period at arbitrary even auxiliary inverse temperature beta = 2p**, for positive integer p. An exact confluent Jack hypergeometric formula gives the period and its energy derivative; its argument is the vector of level energies. This is not an ordinary one-variable Kummer function. An off-shell Bethe vector period satisfies an exact imaginary-time equation in the inverse coupling. Its scalar projection proves that the period energy approaches the physical ground-state energy as p tends to infinity for a fixed finite system. Finite-p equality with a physical eigenenergy and uniformity in the thermodynamic limit do not follow.

Chapter 22 develops the **one-pair saddle route at beta = 2**. Orthogonal-polynomial recurrences prove cancellation of all higher extensive coefficients of the formal expansion, without inserting a continuum Richardson-root distribution. The chapter assembles the ground-period energy, chemical potential, gap parameter, odd blocked-level sector, broken-pair and marked pair-preserving excitations, and thresholds. A scalar certificate controls the ground-period Case B cascade relative to Case A. Statements for some physical and blocked-cascade sectors remain conditional. The text does not equate a formal all-order cancellation with convergence or claim that every physical excitation bridge is complete.

Version 1.3 adds Chapters 23–25 on **duality and self-dual states**. They develop the alternative rapidity equations based on particle–hole duality into a finite polynomial problem, prove ground-branch localization and regularity, derive a real boundary problem and energy-area formula, and recover controlled leading BCS results. The finite spectral representation is related explicitly to the known integrable spin model of Links. Its use does not assert a local-operator identification of every physical observable.

The new excitation part treats blocked defects and the **first self-dual** pair-preserving gap, including finite coalescence bounds and selected weak-coupling joint limits. The two criteria for the accuracy of bulk BCS condensation energy and spectral gap are distinguished, with their Cooper-pair binding interpretation and historical antecedents. The full pair-preserving spectral minimum remains a separate ordering question.

The latest exact reduction extracts one positive Richardson rapidity and describes the other roots by a smooth real response. A scalar condition and an energy integral give the finite excitation. Numerical observations about one Newton correction and a candidate universal crossover limit are separated from proved finite identities.

The duality history starts from the [2012 integral treatment](https://arxiv.org/abs/1111.2907) and the [2015 paper on particle–hole duality](https://arxiv.org/abs/1412.1016), with explicit recognition of earlier charge-variable approaches, the direct use of Richardson roots, and Slavnov-type determinant formulas. No claim that all later work abandoned the direct equations is made. The thermodynamic part does not assume a continuum root arc; it still states its finite spectral and limiting hypotheses.

The beta parameter is auxiliary. Real finite-temperature thermodynamics and general-beta Case B are outside the new release. The older exact period results and their original limitations remain part of the record.

The source archive contains:

- `rg_master.tex`, `preamble.tex`, `frontmatter/`, `chapters/`, `appendices/`, `backmatter/`: complete manuscript sources.
- `bibliography/references.bib`: cited literature, including both 2012 papers and the doctoral dissertation.
- `rg_master.bbl`: bibliography generated for this release, also retained for direct LaTeX compilation.
- `code/duality_selfdual/`: the complete v0.1 checkpoint, the recovered finite spectral dependency `selfdual_iteration5.zip`, and the fresh fourth-edition numerical audit. The original input packages retain their own provenance and checksums.
- `code/`: retained scientific verification programs and labelled historical reports, the `pfaffian_caseA/` library, and the added `even_beta_caseA/` and `one_pair_saddle/` supporting programs and reports. The local README files specify dependencies and scope.
- `requirements_optional.txt`: optional dependencies for the earlier scientific programs.
- `revision/`: the current verification report, change record, provenance, and next mathematical tasks.
- `CITATION.bib`: citation information without an invented deposit DOI.
- `RIGHTS.md`: note on the licence choice to be made for the deposit.
- `SHA256SUMS`: hashes of the source archive's contents.

## Build the manuscript

Use a TeX distribution containing pdfLaTeX, latexmk, BibTeX, Latin Modern fonts, AMS packages, mathrsfs, mathtools, microtype, natbib, hyperref, cleveref, geometry, fancyhdr, enumitem, booktabs, longtable, tabularx, and xcolor. No external figures or proprietary fonts are required.

From the extracted source directory:

```sh
python3 build_pdf.py
```

This helper refreshes the bibliography, builds `build/rg_master.pdf`, and selects an available BibTeX executable. With the supplied current bibliography, the manuscript can also be compiled directly:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build rg_master.tex
```

If the local executable is named `bibtex.original`, the helper uses it automatically. The included `.bbl` also permits direct pdfLaTeX compilation without running BibTeX; several passes are needed for cross-references. Rebuild the bibliography after editing citations.

## Reproduce the retained lattice check

```sh
python3 code/verify_revision01.py
```

The checker uses only the Python standard library. The retained run used Python 3.12.14. It performs 96 finite exact-arithmetic comparisons, 24 larger confluent-minor and derivative checks, and a regression reproducing the failure of the discarded gamma continuation. Output is written to `revision/verification_revision01.txt`.

“Independent” or “separately implemented” refers to a separate LLM-generated implementation that imports no earlier verification module. It does not mean independent human verification. The retained Revision 01 report documents its historical run. Current reports specify the checks run for version 1.3; inclusion of the earlier suite does not by itself mean that all of it was rerun. Historical reports are in `code/archive_module18_reports/`; their PASS results have the scope of the particular old tests. See `code/README.md` for the optional dependencies and the tasks of each program.

## Reproduce the Case A Pfaffian checks

See `code/pfaffian_caseA/README.md` for commands, dependencies, precision, and the scope of the two drivers. They are independent of the older Case B modules. Their current reports cover finite moment/residue identities, logarithmic derivatives, normalization, positive low-dimensional integrals, and fixed-spectrum coupling coefficients.

## Reproduce the version 1.2 additions

See `code/even_beta_caseA/README.md` and `code/one_pair_saddle/README.md` for the corresponding commands, dependencies, included derivations, and the exact scope of each report. The first concerns the general even-beta common Case A period and its finite-system physical bridge. The second concerns the formal Gaussian cancellations and the finite-period blocked-level and cascade calculations used in Chapter 22.

Finite algebraic comparisons, numerical checks, and a finite-order symbolic series check serve different purposes. None alone establishes uniform large-system errors, convergence of the formal saddle series, or the unresolved blocked-cascade and physical branch identifications.

## Reproduce the version 1.3 additions

See `code/duality_selfdual/README.md` and `code/duality_selfdual/revision_validation/README.md`. `revision/DUALITY_NUMERICS_v1_3.md` records the current finite identities, reconstruction, small-system diagonalizations, and selected crossover/response checks. Mathematical audit notes identify the proofs and dependencies reviewed. `revision/BUILD_QA_v1_3.json` records the final PDF build and package checks.

The original checkpoint is preserved unchanged. Its archived numerical tables are not all presented as newly rerun calculations. The current checks use floating-point arithmetic unless a report explicitly states exact rational or symbolic arithmetic. Small-system agreement is not a proof of the full-spectrum ordering or of uniform accuracy in a crossover limit.

## Citation and deposit information

Until Zenodo assigns a DOI, cite the title, author, working-manuscript status, and version 1.3. The prior-paper and thesis DOIs refer to those earlier works, not to this manuscript. The preparation date is not a claim that the record has already been published. Use the actual publication date and new DOI when finalizing the Zenodo record.

No open reuse licence has been selected on the author's behalf in this package. See `RIGHTS.md`; the depositor should select the intended licence in Zenodo before publication.
